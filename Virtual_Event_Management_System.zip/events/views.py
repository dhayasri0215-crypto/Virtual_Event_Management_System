from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Sum, Count
from django.http import HttpResponse, JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.core.paginator import Paginator
from django.urls import reverse
from uuid import uuid4
from .models import *
from .forms import *
import io
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from openpyxl import Workbook

@login_required
def dashboard(request):
    events = Event.objects.filter(organizer=request.user).select_related("venue")
    upcoming = events.filter(start_date__gte=timezone.now()).order_by("start_date")[:5]
    context = {
        "event_count": events.count(),
        "venue_count": Venue.objects.filter(is_active=True).count(),
        "guest_count": Guest.objects.filter(event__organizer=request.user).count(),
        "vendor_count": Vendor.objects.filter(is_active=True).count(),
        "upcoming": upcoming,
        "planned": events.filter(status="planned").count(),
        "completed": events.filter(status="completed").count(),
        "budget_total": events.aggregate(v=Sum("budget"))["v"] or 0,
    }
    return render(request, "events/dashboard.html", context)

def crud_list(request, model, template, context_name, title):
    qs = model.objects.all()
    if model == Event:
        qs = qs.filter(organizer=request.user).select_related("venue")
    paginator = Paginator(qs, 10)
    page = request.GET.get("page")
    return render(request, template, {"object_list": paginator.get_page(page), "title": title, "context_name": context_name})

@login_required
def event_list(request): return crud_list(request, Event, "events/event_list.html", "events", "Events")

@login_required
def event_create(request):
    form = EventForm(request.POST or None)
    if form.is_valid():
        obj = form.save(commit=False); obj.organizer = request.user; obj.save()
        messages.success(request, "Event created successfully."); return redirect("event_detail", obj.pk)
    return render(request, "events/form.html", {"form":form,"title":"Create Event","back_url":reverse("event_list")})

@login_required
def event_detail(request, pk):
    event = get_object_or_404(Event, pk=pk, organizer=request.user)
    return render(request, "events/event_detail.html", {
        "event":event, "guests":event.guests.all(), "vendors":event.event_vendors.select_related("vendor"),
        "catering":event.catering_orders.all(), "budget_items":event.budget_items.select_related("vendor"),
        "schedule":event.schedule.all(), "invitations":Invitation.objects.filter(guest__event=event),
        "actual_total":event.budget_items.aggregate(v=Sum("actual_cost"))["v"] or 0,
    })

@login_required
def event_edit(request, pk):
    event=get_object_or_404(Event,pk=pk,organizer=request.user); form=EventForm(request.POST or None,instance=event)
    if form.is_valid(): form.save(); messages.success(request,"Event updated."); return redirect("event_detail",pk)
    return render(request,"events/form.html",{"form":form,"title":"Edit Event","back_url":reverse("event_detail",args=[pk])})

@login_required
def event_delete(request, pk):
    event=get_object_or_404(Event,pk=pk,organizer=request.user)
    if request.method=="POST": event.delete(); messages.success(request,"Event deleted."); return redirect("event_list")
    return render(request,"events/confirm_delete.html",{"object":event,"back_url":reverse("event_list")})

@login_required
def venue_list(request):
    return render(request,"events/venue_list.html",{"venues":Venue.objects.all()})
@login_required
def venue_create(request):
    form=VenueForm(request.POST or None,request.FILES or None)
    if form.is_valid(): form.save(); messages.success(request,"Venue added."); return redirect("venue_list")
    return render(request,"events/form.html",{"form":form,"title":"Add Venue","back_url":reverse("venue_list")})

@login_required
def vendor_list(request):
    return render(request,"events/vendor_list.html",{"vendors":Vendor.objects.all()})
@login_required
def vendor_create(request):
    form=VendorForm(request.POST or None)
    if form.is_valid(): form.save(); messages.success(request,"Vendor added."); return redirect("vendor_list")
    return render(request,"events/form.html",{"form":form,"title":"Add Vendor","back_url":reverse("vendor_list")})

def _event_for_user(request, pk):
    return get_object_or_404(Event, pk=pk, organizer=request.user)

@login_required
def guest_add(request, event_id):
    event=_event_for_user(request,event_id); form=GuestForm(request.POST or None)
    if form.is_valid():
        g=form.save(commit=False); g.event=event; g.save(); messages.success(request,"Guest added."); return redirect("event_detail",event_id)
    return render(request,"events/form.html",{"form":form,"title":f"Add Guest — {event.name}","back_url":reverse("event_detail",args=[event_id])})

@login_required
def catering_add(request,event_id):
    event=_event_for_user(request,event_id); form=CateringOrderForm(request.POST or None)
    if form.is_valid():
        x=form.save(commit=False); x.event=event; x.save(); messages.success(request,"Catering order added."); return redirect("event_detail",event_id)
    return render(request,"events/form.html",{"form":form,"title":f"Add Catering — {event.name}","back_url":reverse("event_detail",args=[event_id])})

@login_required
def budget_add(request,event_id):
    event=_event_for_user(request,event_id); form=BudgetItemForm(request.POST or None)
    if form.is_valid():
        x=form.save(commit=False); x.event=event; x.save(); messages.success(request,"Budget item added."); return redirect("event_detail",event_id)
    return render(request,"events/form.html",{"form":form,"title":f"Add Budget Item — {event.name}","back_url":reverse("event_detail",args=[event_id])})

@login_required
def schedule_add(request,event_id):
    event=_event_for_user(request,event_id); form=ScheduleItemForm(request.POST or None)
    if form.is_valid():
        x=form.save(commit=False); x.event=event; x.save(); messages.success(request,"Schedule item added."); return redirect("event_detail",event_id)
    return render(request,"events/form.html",{"form":form,"title":f"Add Schedule Item — {event.name}","back_url":reverse("event_detail",args=[event_id])})

@login_required
def event_vendor_add(request,event_id):
    event=_event_for_user(request,event_id); form=EventVendorForm(request.POST or None)
    if form.is_valid():
        x=form.save(commit=False); x.event=event; x.save(); messages.success(request,"Vendor assigned."); return redirect("event_detail",event_id)
    return render(request,"events/form.html",{"form":form,"title":f"Assign Vendor — {event.name}","back_url":reverse("event_detail",args=[event_id])})

@login_required
def invitation_create(request,event_id,guest_id):
    event=_event_for_user(request,event_id); guest=get_object_or_404(Guest,pk=guest_id,event=event)
    if request.method=="POST":
        Invitation.objects.create(guest=guest,invitation_code=uuid4().hex[:12].upper(),sent_date=timezone.now())
        messages.success(request,"Invitation created."); return redirect("event_detail",event_id)
    return render(request,"events/confirm_delete.html",{"object":guest,"back_url":reverse("event_detail",args=[event_id]),"confirm_text":"Create invitation for this guest?"})

@login_required
def reports(request):
    events=Event.objects.filter(organizer=request.user)
    data=[]
    for e in events:
        actual=e.budget_items.aggregate(v=Sum("actual_cost"))["v"] or 0
        data.append({"name":e.name,"budget":float(e.budget),"actual":float(actual),"guests":e.guests.count()})
    return render(request,"events/reports.html",{"data":data,"events":events})

@login_required
def export_excel(request):
    events=Event.objects.filter(organizer=request.user)
    wb=Workbook(); ws=wb.active; ws.title="Event Report"
    ws.append(["Event","Type","Venue","Start","End","Expected Guests","Budget","Actual Expense","Status"])
    for e in events:
        actual=e.budget_items.aggregate(v=Sum("actual_cost"))["v"] or 0
        ws.append([e.name,e.get_event_type_display(),e.venue.name,e.start_date.replace(tzinfo=None),e.end_date.replace(tzinfo=None),e.expected_guests,float(e.budget),float(actual),e.get_status_display()])
    response=HttpResponse(content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    response["Content-Disposition"]='attachment; filename="event_report.xlsx"'
    wb.save(response); return response

@login_required
def export_pdf(request):
    events=Event.objects.filter(organizer=request.user)
    buffer=io.BytesIO(); p=canvas.Canvas(buffer,pagesize=A4); y=800
    p.setFont("Helvetica-Bold",18); p.drawString(45,y,"Virtual Event Management - Report"); y-=35
    p.setFont("Helvetica",9)
    for e in events:
        actual=e.budget_items.aggregate(v=Sum("actual_cost"))["v"] or 0
        line=f"{e.name} | {e.get_event_type_display()} | Guests: {e.expected_guests} | Budget: Rs.{e.budget} | Actual: Rs.{actual} | {e.get_status_display()}"
        p.drawString(45,y,line[:115]); y-=18
        if y<60: p.showPage(); y=800; p.setFont("Helvetica",9)
    p.save(); buffer.seek(0)
    response=HttpResponse(buffer.read(),content_type="application/pdf")
    response["Content-Disposition"]='attachment; filename="event_report.pdf"'
    return response

@login_required
def api_dashboard(request):
    events=Event.objects.filter(organizer=request.user)
    return JsonResponse({
        "events":events.count(),"guests":Guest.objects.filter(event__in=events).count(),
        "venues":Venue.objects.filter(is_active=True).count(),"vendors":Vendor.objects.filter(is_active=True).count(),
        "budget":float(events.aggregate(v=Sum("budget"))["v"] or 0),
    })
