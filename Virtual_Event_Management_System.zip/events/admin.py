from django.contrib import admin
from .models import *
admin.site.register([Venue, Vendor, Event, EventVendor, Guest, CateringOrder, BudgetItem, ScheduleItem, Invitation])
