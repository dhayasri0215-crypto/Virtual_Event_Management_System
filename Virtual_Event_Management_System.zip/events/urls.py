from django.urls import path
from . import views
urlpatterns = [
    path("", views.dashboard, name="dashboard"),
    path("events/", views.event_list, name="event_list"),
    path("events/create/", views.event_create, name="event_create"),
    path("events/<int:pk>/", views.event_detail, name="event_detail"),
    path("events/<int:pk>/edit/", views.event_edit, name="event_edit"),
    path("events/<int:pk>/delete/", views.event_delete, name="event_delete"),
    path("events/<int:event_id>/guests/add/", views.guest_add, name="guest_add"),
    path("events/<int:event_id>/catering/add/", views.catering_add, name="catering_add"),
    path("events/<int:event_id>/budget/add/", views.budget_add, name="budget_add"),
    path("events/<int:event_id>/schedule/add/", views.schedule_add, name="schedule_add"),
    path("events/<int:event_id>/vendors/add/", views.event_vendor_add, name="event_vendor_add"),
    path("events/<int:event_id>/guests/<int:guest_id>/invitation/", views.invitation_create, name="invitation_create"),
    path("venues/", views.venue_list, name="venue_list"),
    path("venues/create/", views.venue_create, name="venue_create"),
    path("vendors/", views.vendor_list, name="vendor_list"),
    path("vendors/create/", views.vendor_create, name="vendor_create"),
    path("reports/", views.reports, name="reports"),
    path("reports/excel/", views.export_excel, name="export_excel"),
    path("reports/pdf/", views.export_pdf, name="export_pdf"),
    path("api/dashboard/", views.api_dashboard, name="api_dashboard"),
]
