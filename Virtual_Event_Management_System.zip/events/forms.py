from django import forms
from .models import *

class StyledModelForm(forms.ModelForm):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field in self.fields.values():
            cls = "form-control"
            if isinstance(field.widget, forms.Select):
                cls = "form-select"
            if isinstance(field.widget, forms.CheckboxInput):
                cls = "form-check-input"
            field.widget.attrs["class"] = cls

class EventForm(StyledModelForm):
    class Meta:
        model = Event
        fields = ["name","description","event_type","venue","start_date","end_date","expected_guests","budget","status","notes"]
        widgets = {
            "start_date": forms.DateTimeInput(attrs={"type":"datetime-local"}),
            "end_date": forms.DateTimeInput(attrs={"type":"datetime-local"}),
        }

class VenueForm(StyledModelForm):
    class Meta:
        model = Venue
        fields = "__all__"
        exclude = ["created_at","updated_at"]

class VendorForm(StyledModelForm):
    class Meta:
        model = Vendor
        fields = "__all__"
        exclude = ["created_at","updated_at"]

class GuestForm(StyledModelForm):
    class Meta:
        model = Guest
        exclude = ["event","invited_at","responded_at","created_at","updated_at"]

class CateringOrderForm(StyledModelForm):
    class Meta:
        model = CateringOrder
        exclude = ["event","created_at","updated_at"]
        widgets = {"delivery_time": forms.DateTimeInput(attrs={"type":"datetime-local"})}

class BudgetItemForm(StyledModelForm):
    class Meta:
        model = BudgetItem
        exclude = ["event","created_at","updated_at"]

class ScheduleItemForm(StyledModelForm):
    class Meta:
        model = ScheduleItem
        exclude = ["event","created_at","updated_at"]
        widgets = {
            "start_time": forms.DateTimeInput(attrs={"type":"datetime-local"}),
            "end_time": forms.DateTimeInput(attrs={"type":"datetime-local"}),
        }

class EventVendorForm(StyledModelForm):
    class Meta:
        model = EventVendor
        exclude = ["event","created_at","updated_at"]

class InvitationForm(StyledModelForm):
    class Meta:
        model = Invitation
        exclude = ["invitation_code","invitation_date","sent_date","delivered_date","opened_date","created_at","updated_at"]
