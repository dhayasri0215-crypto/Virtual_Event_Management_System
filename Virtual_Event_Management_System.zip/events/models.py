from django.db import models
from django.contrib.auth.models import User

EVENT_TYPES = [
    ("wedding", "Wedding"), ("corporate", "Corporate Event"),
    ("birthday", "Birthday Party"), ("anniversary", "Anniversary"),
    ("conference", "Conference"), ("concert", "Concert"),
    ("exhibition", "Exhibition"), ("other", "Other"),
]

class Venue(models.Model):
    name = models.CharField(max_length=200)
    description = models.TextField()
    address = models.TextField()
    city = models.CharField(max_length=50)
    state = models.CharField(max_length=50)
    country = models.CharField(max_length=50)
    capacity = models.IntegerField()
    price_per_hour = models.DecimalField(max_digits=10, decimal_places=2)
    amenities = models.TextField(blank=True)
    image = models.ImageField(upload_to="venues/", blank=True, null=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __str__(self): return self.name
    class Meta: ordering = ["name"]

class Vendor(models.Model):
    VENDOR_TYPES = [
        ("catering","Catering"),("decoration","Decoration"),("photography","Photography"),
        ("entertainment","Entertainment"),("transportation","Transportation"),
        ("florist","Florist"),("other","Other"),
    ]
    name = models.CharField(max_length=200)
    vendor_type = models.CharField(max_length=20, choices=VENDOR_TYPES)
    description = models.TextField(blank=True)
    contact_person = models.CharField(max_length=100)
    phone = models.CharField(max_length=15)
    email = models.EmailField()
    address = models.TextField(blank=True)
    rating = models.DecimalField(max_digits=3, decimal_places=2, default=0)
    total_reviews = models.IntegerField(default=0)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __str__(self): return self.name
    class Meta: ordering = ["name"]

class Event(models.Model):
    STATUS_CHOICES = [
        ("draft","Draft"),("planned","Planned"),("in_progress","In Progress"),
        ("completed","Completed"),("cancelled","Cancelled"),
    ]
    name = models.CharField(max_length=200)
    description = models.TextField()
    event_type = models.CharField(max_length=20, choices=EVENT_TYPES)
    venue = models.ForeignKey(Venue, on_delete=models.CASCADE, related_name="events")
    organizer = models.ForeignKey(User, on_delete=models.CASCADE, related_name="organized_events")
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()
    expected_guests = models.PositiveIntegerField()
    budget = models.DecimalField(max_digits=12, decimal_places=2)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default="draft")
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __str__(self): return self.name
    class Meta: ordering = ["-start_date"]

class EventVendor(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name="event_vendors")
    vendor = models.ForeignKey(Vendor, on_delete=models.CASCADE, related_name="event_vendors")
    service_agreed = models.TextField()
    cost = models.DecimalField(max_digits=10, decimal_places=2)
    is_confirmed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    class Meta: unique_together = ["event", "vendor"]

class Guest(models.Model):
    RESPONSE_CHOICES = [("pending","Pending"),("accepted","Accepted"),("declined","Declined"),("maybe","Maybe")]
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name="guests")
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=15, blank=True)
    company = models.CharField(max_length=200, blank=True)
    job_title = models.CharField(max_length=100, blank=True)
    response = models.CharField(max_length=20, choices=RESPONSE_CHOICES, default="pending")
    dietary_requirements = models.TextField(blank=True)
    special_requests = models.TextField(blank=True)
    invited_at = models.DateTimeField(auto_now_add=True)
    responded_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __str__(self): return f"{self.first_name} {self.last_name}"
    class Meta:
        ordering = ["first_name"]
        unique_together = ["event", "email"]

class CateringOrder(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name="catering_orders")
    menu_items = models.TextField()
    total_guests = models.PositiveIntegerField()
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    delivery_time = models.DateTimeField()
    special_instructions = models.TextField(blank=True)
    is_confirmed = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __str__(self): return f"{self.event.name} - Catering"

class BudgetItem(models.Model):
    CATEGORY_CHOICES = [
        ("venue","Venue"),("catering","Catering"),("decoration","Decoration"),
        ("entertainment","Entertainment"),("staff","Staff"),("transport","Transportation"),
        ("equipment","Equipment"),("marketing","Marketing"),("other","Other"),
    ]
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name="budget_items")
    category = models.CharField(max_length=20, choices=CATEGORY_CHOICES)
    description = models.TextField()
    estimated_cost = models.DecimalField(max_digits=10, decimal_places=2)
    actual_cost = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    vendor = models.ForeignKey(Vendor, on_delete=models.SET_NULL, null=True, blank=True)
    is_paid = models.BooleanField(default=False)
    paid_date = models.DateField(null=True, blank=True)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __str__(self): return f"{self.event.name} - {self.category}"

class ScheduleItem(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name="schedule")
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    location = models.CharField(max_length=200, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __str__(self): return f"{self.event.name} - {self.title}"
    class Meta: ordering = ["start_time"]

class Invitation(models.Model):
    INVITATION_STATUS = [("sent","Sent"),("delivered","Delivered"),("opened","Opened"),("responded","Responded")]
    guest = models.ForeignKey(Guest, on_delete=models.CASCADE, related_name="invitations")
    invitation_code = models.CharField(max_length=50, unique=True)
    invitation_date = models.DateTimeField(auto_now_add=True)
    sent_date = models.DateTimeField(null=True, blank=True)
    delivered_date = models.DateTimeField(null=True, blank=True)
    opened_date = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=INVITATION_STATUS, default="sent")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __str__(self): return f"Invitation for {self.guest}"
