from django.core.management.base import BaseCommand
from seed_demo import run
class Command(BaseCommand):
    help = "Create demo data for EventSphere"
    def handle(self, *args, **options):
        run()
        self.stdout.write(self.style.SUCCESS("Demo data created successfully."))
