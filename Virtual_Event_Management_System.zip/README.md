# EventSphere — Virtual Event Management System

**Internship Task:** PY-HR-004  
**Domain:** Hospitality Event Management  
**Framework:** Django + Python  
**Database:** MySQL 8.x  
**Frontend:** HTML5, CSS3, Bootstrap 5, JavaScript, Chart.js

## Included modules
- User authentication
- Dashboard
- Event CRUD
- Venue management
- Guest management and RSVP status
- Invitation generation
- Vendor management and event-vendor assignment
- Catering orders
- Event budget tracking
- Event scheduling
- PDF and Excel reports
- Chart.js analytics
- Django admin
- REST-style JSON dashboard endpoint

## 1. Create MySQL database

Open MySQL Workbench and run:

```sql
CREATE DATABASE event_management CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

## 2. Install dependencies

```bash
python -m venv venv
```

Windows:
```bash
venv\Scripts\activate
```

Linux/macOS:
```bash
source venv/bin/activate
```

Then:
```bash
pip install -r requirements.txt
```

If `mysqlclient` fails on Windows, install the matching MySQL C connector/build tools or use a Python environment where the mysqlclient wheel is available.

## 3. Configure database

Copy `.env.example` values into your environment, or edit `event_management/settings.py`.

For a local MySQL root account with no password, the default settings work.

## 4. Create tables

```bash
python manage.py makemigrations
python manage.py migrate
```

## 5. Create admin user

```bash
python manage.py createsuperuser
```

## 6. Optional demo data

```bash
python manage.py seed_demo
```

Demo login:
- Username: `demo`
- Password: `demo1234`

## 7. Run

```bash
python manage.py runserver
```

Open:
http://127.0.0.1:8000/

Admin:
http://127.0.0.1:8000/admin/

## Project structure

event_management/
  settings.py
  urls.py
  wsgi.py

events/
  models.py
  forms.py
  views.py
  urls.py
  admin.py
  migrations/
  management/commands/seed_demo.py

templates/
static/
media/

## Important note

This package is a complete academic/internship starter implementation. For production deployment, add stronger password validators, secure secret management, HTTPS, email delivery, object-level permissions, database backups, validation for overlapping venue bookings, and production static/media hosting.
