from datetime import timedelta
from django.contrib.auth.models import User
from django.utils import timezone
from events.models import Venue, Vendor, Event, Guest, BudgetItem, ScheduleItem, CateringOrder

def run():
    user, _ = User.objects.get_or_create(username="demo")
    if not user.has_usable_password(): user.set_password("demo1234"); user.save()
    elif not user.check_password("demo1234"): user.set_password("demo1234"); user.save()

    v, _ = Venue.objects.get_or_create(name="Grand Orchid Convention Hall", defaults={
        "description":"Modern premium event venue with stage and dining area.",
        "address":"MG Road","city":"Chennai","state":"Tamil Nadu","country":"India",
        "capacity":500,"price_per_hour":5000,"amenities":"WiFi, Parking, Stage, AC, Projector"
    })
    vendor, _ = Vendor.objects.get_or_create(name="Royal Caterers", defaults={
        "vendor_type":"catering","description":"Full-service event catering","contact_person":"Arun Kumar",
        "phone":"9876543210","email":"royal@example.com","address":"Chennai","rating":4.5,"total_reviews":120
    })
    start=timezone.now()+timedelta(days=14)
    e, _ = Event.objects.get_or_create(name="Tech Fest 2026", organizer=user, defaults={
        "description":"Annual technology and innovation event.",
        "event_type":"conference","venue":v,"start_date":start,
        "end_date":start+timedelta(hours=6),"expected_guests":250,"budget":250000,
        "status":"planned","notes":"Demo event created by seed script."
    })
    Guest.objects.get_or_create(event=e,email="student@example.com",defaults={"first_name":"Kavin","last_name":"Raj","phone":"9000000000","response":"accepted"})
    BudgetItem.objects.get_or_create(event=e,category="venue",description="Venue booking",defaults={"estimated_cost":30000,"actual_cost":30000})
    BudgetItem.objects.get_or_create(event=e,category="catering",description="Lunch and refreshments",vendor=vendor,defaults={"estimated_cost":90000,"actual_cost":85000})
    ScheduleItem.objects.get_or_create(event=e,title="Opening Ceremony",defaults={"description":"Welcome and keynote","start_time":start,"end_time":start+timedelta(hours=1),"location":"Main Hall"})
    CateringOrder.objects.get_or_create(event=e,delivery_time=start+timedelta(hours=2),defaults={"menu_items":"Lunch buffet, Tea, Coffee","total_guests":250,"total_amount":85000,"is_confirmed":True})
    print("Demo data created. Login: demo / demo1234")
