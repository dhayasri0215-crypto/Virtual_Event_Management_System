CREATE DATABASE IF NOT EXISTS event_management
CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE event_management;
